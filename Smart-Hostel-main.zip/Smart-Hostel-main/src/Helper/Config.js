export const Config = {
  //-------------------------------------------------Base Url---------------------------------

  API_URL: 'https://deva.ncs-it.co.uk/tinav2/',
  Token: 'Basic YXBpVGluYVVzZXI6ak44JHFGMUBvUDUmY1k0Jm1OM0A=',
};
