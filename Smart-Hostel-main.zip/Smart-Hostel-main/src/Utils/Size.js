export const fontSize = {
  Splash: 22,
  lable: 16,
  txt: 14,
  small: 12,
};

export const radious = {
  borderradious: 10,
  radiousfive: 5,
  tagsradious: 50
};
export const paddview = { s: '2%', M: '5%' };
