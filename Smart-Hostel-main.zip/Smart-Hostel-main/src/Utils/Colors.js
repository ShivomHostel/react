 

export const colors = {
  AppDefaultColor: '#ffc107',
  statusbarColor: '#303f9f',
  white: '#FFFFFF',
  black: '#000',
  grey: '#808080',
  red: '#ff0000',
  green:'#228b22',
  lightygrey: '#D3D3D3',
  darkgrey:'#4c4747',
  txtgrey: '#4d4d33',
  btn:'#ffc107',
  navy:'#3D30A2',
  purple:'#99ccff',
  orange:'#ffc107',
  yellow:'#FFFB73'
};
