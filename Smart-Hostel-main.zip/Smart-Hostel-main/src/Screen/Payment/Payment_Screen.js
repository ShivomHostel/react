import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Payment_Screen = () => {
  return (
    <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
      <Text>Coming Soon</Text>
    </View>
  )
}

export default Payment_Screen

const styles = StyleSheet.create({})