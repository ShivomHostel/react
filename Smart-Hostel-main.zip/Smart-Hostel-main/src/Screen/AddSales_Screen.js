import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const AddSales_Screen = () => {
  return (
    <View>
      <Text>AddSales_Screen</Text>
    </View>
  )
}

export default AddSales_Screen

const styles = StyleSheet.create({})