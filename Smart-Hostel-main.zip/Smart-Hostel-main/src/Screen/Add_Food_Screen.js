import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Add_Food_Screen = () => {
  return (
    <View>
      <Text>Add_Food_Screen</Text>
    </View>
  )
}

export default Add_Food_Screen

const styles = StyleSheet.create({})