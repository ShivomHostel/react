import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { WebView } from 'react-native-webview';


const Add_Registration = () => {
  return (
    <View style={styles.container}>
       
    </View>
  )
}

export default Add_Registration

const styles = StyleSheet.create({
  container:{
    flex:1
  }
})