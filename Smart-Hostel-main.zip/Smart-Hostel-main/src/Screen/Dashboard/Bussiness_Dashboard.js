import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Bussiness_Dashboard = () => {
  return (
    <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
      <Text>Coming Soon</Text>
    </View>
  )
}

export default Bussiness_Dashboard

const styles = StyleSheet.create({})