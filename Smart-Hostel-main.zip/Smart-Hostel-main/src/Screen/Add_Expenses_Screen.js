import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Add_Expenses_Screen = () => {
  return (
    <View>
      <Text>Add_Expenses_Screen</Text>
    </View>
  )
}

export default Add_Expenses_Screen

const styles = StyleSheet.create({})